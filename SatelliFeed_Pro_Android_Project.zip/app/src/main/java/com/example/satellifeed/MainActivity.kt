package com.example.satellifeed

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {
    private lateinit var prefs: Prefs
    private lateinit var statusText: TextView
    private lateinit var statusDot: TextView
    private lateinit var keywordInput: EditText
    private lateinit var feedList: LinearLayout
    private lateinit var satelliteSearch: EditText
    private var selectedCategory: String = "همه"

    private val bg = Color.rgb(8, 16, 32)
    private val card = Color.rgb(17, 29, 50)
    private val accent = Color.rgb(36, 190, 255)
    private val muted = Color.rgb(155, 174, 198)
    private val white = Color.rgb(238, 246, 255)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        buildUi()
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    private fun buildUi() {
        val density = resources.displayMetrics.density
        fun dp(n: Int) = (n * density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(18), dp(18), dp(18), dp(14))
        }

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(root)
        }

        root.addView(label("SATELLIFEED", 26f, white, true).apply {
            letterSpacing = 0.08f
        })
        root.addView(label("Satellite feed monitor  •  @hacksatfeed", 13f, muted, false))
        root.addView(space(18))

        val hero = panel()
        hero.addView(label("🛰️  پایش زنده فیدهای ماهواره‌ای", 19f, white, true))
        hero.addView(space(8))
        hero.addView(label("جدیدترین گزارش‌های فید از SatelliWeb را دنبال کنید و در صورت انتشار مورد جدید، اعلان دریافت کنید.", 14f, muted))
        hero.addView(space(14))
        val statusRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        statusDot = label("●", 16f, Color.rgb(255, 190, 60), true)
        statusRow.addView(statusDot)
        statusRow.addView(label("  آماده برای شروع پایش", 14f, white, true))
        hero.addView(statusRow)
        statusText = label("آخرین بررسی: ${prefs.lastCheck}", 12f, muted)
        hero.addView(statusText)
        root.addView(hero)

        root.addView(space(14))
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val start = actionButton("▶  شروع پایش", accent, bg)
        start.setOnClickListener {
            prefs.keywords = keywordInput.text.toString()
            schedule()
            statusDot.setTextColor(Color.rgb(65, 220, 140))
            statusText.text = "پایش خودکار فعال شد • بررسی هر ۱۵ دقیقه"
            Toast.makeText(this, "پایش خودکار فعال شد", Toast.LENGTH_SHORT).show()
        }
        actions.addView(start, LinearLayout.LayoutParams(0, dp(52), 1f))
        val check = actionButton("⟳  بررسی الآن", Color.rgb(34, 53, 80), white)
        check.setOnClickListener {
            prefs.keywords = keywordInput.text.toString()
            WorkManager.getInstance(this).enqueue(OneTimeWorkRequestBuilder<FeedWorker>().build())
            window.decorView.postDelayed({ renderFeeds(); statusText.text = "آخرین بررسی: ${prefs.lastCheck}" }, 7000)
            statusText.text = "در حال بررسی فیدهای جدید…"
            Toast.makeText(this, "درخواست بررسی ارسال شد", Toast.LENGTH_SHORT).show()
        }
        actions.addView(check, LinearLayout.LayoutParams(0, dp(52), 1f).apply { leftMargin = dp(8) })
        root.addView(actions)

        root.addView(space(16))
        val filter = panel()
        filter.addView(label("🔎  فیلتر موضوعی", 17f, white, true))
        filter.addView(space(5))
        filter.addView(label("کلمات را با کاما جدا کنید. خالی گذاشتن فیلد یعنی دریافت همه فیدها.", 13f, muted))
        keywordInput = EditText(this).apply {
            setText(prefs.keywords)
            hint = "football, basketball, hot bird"
            setHintTextColor(muted)
            setTextColor(white)
            textSize = 14f
            setSingleLine(false)
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(Color.rgb(8, 16, 32))
        }
        filter.addView(keywordInput, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)))
        filter.addView(space(10))
        filter.addView(actionButton("ذخیره فیلترها", Color.rgb(34, 53, 80), white).apply {
            setOnClickListener {
                prefs.keywords = keywordInput.text.toString()
                Toast.makeText(this@MainActivity, "فیلترها ذخیره شدند", Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(filter)

        root.addView(space(16))
        val feedsPanel = panel()
        feedsPanel.addView(label("📋  آخرین فیدهای دریافتی", 17f, white, true))
        feedsPanel.addView(space(8))
        satelliteSearch = EditText(this).apply {
            hint = "جستجوی ماهواره، فرکانس یا شبکه..."
            setHintTextColor(muted)
            setTextColor(white)
            textSize = 14f
            setSingleLine(true)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(Color.rgb(8, 16, 32))
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { renderFeeds() }
                override fun afterTextChanged(s: android.text.Editable?) {}
            })
        }
        feedsPanel.addView(satelliteSearch, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50)))
        feedsPanel.addView(space(8))
        val categoryRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("همه", "فوتبال", "بسکتبال").forEach { category ->
            categoryRow.addView(actionButton(category, if (selectedCategory == category) accent else Color.rgb(34, 53, 80),
                if (selectedCategory == category) bg else white).apply {
                setOnClickListener {
                    selectedCategory = category
                    renderFeeds()
                    // Update category button highlighting.
                    for (i in 0 until categoryRow.childCount) {
                        val b = categoryRow.getChildAt(i) as Button
                        val active = b.text.toString() == selectedCategory
                        b.setBackgroundColor(if (active) accent else Color.rgb(34, 53, 80))
                        b.setTextColor(if (active) bg else white)
                    }
                }
            }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { if (category != "همه") leftMargin = dp(6) })
        }
        feedsPanel.addView(categoryRow)
        feedsPanel.addView(space(10))
        feedList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        feedsPanel.addView(feedList)
        root.addView(feedsPanel)
        renderFeeds()

        root.addView(space(16))
        val info = panel()
        info.addView(label("📡  درباره پایش", 17f, white, true))
        info.addView(space(8))
        info.addView(label("• منبع: SatelliWeb Live Feeds\n• بررسی خودکار: هر ۱۵ دقیقه (در صورت اتصال اینترنت)\n• اعلان فقط برای فیدهای جدید پس از اولین بررسی\n• برای جلوگیری از اعلان‌های زیاد، فیلتر کلمات کلیدی قابل تنظیم است", 13f, muted))
        root.addView(info)

        root.addView(space(14))
        root.addView(actionButton("🌐  مشاهده وب‌سایت SatelliWeb", Color.rgb(17, 29, 50), accent).apply {
            setOnClickListener { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(FEED_URL))) }
        })
        root.addView(space(12))
        root.addView(label("SatelliFeed  •  ساخته شده برای جامعه @hacksatfeed", 11f, muted).apply {
            gravity = Gravity.CENTER
        })

        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        if (::feedList.isInitialized) renderFeeds()
    }

    private fun renderFeeds() {
        if (!::feedList.isInitialized) return
        feedList.removeAllViews()
        val words = if (::keywordInput.isInitialized) keywordInput.text.toString().lowercase()
            .split(",").map { it.trim() }.filter { it.isNotEmpty() } else emptyList()
        val query = if (::satelliteSearch.isInitialized) satelliteSearch.text.toString().trim().lowercase() else ""
        val items = prefs.latest().filter { item ->
            val keywordMatch = words.isEmpty() || words.any { it in item.searchable }
            val categoryMatch = when (selectedCategory) {
                "فوتبال" -> item.searchable.contains("football") || item.searchable.contains("فوتبال")
                "بسکتبال" -> item.searchable.contains("basketball") || item.searchable.contains("بسکتبال")
                else -> true
            }
            val searchMatch = query.isEmpty() ||
                "${
                    item.satellite
                } ${item.frequency} ${item.pol} ${item.sr} ${item.category} ${item.info} ${item.transmitted}"
                    .lowercase().contains(query)
            keywordMatch && categoryMatch && searchMatch
        }
        if (items.isEmpty()) {
            feedList.addView(label("هنوز فیدی ذخیره نشده است. برای دریافت اطلاعات، «بررسی الآن» را بزنید.", 13f, muted))
            return
        }
        items.take(50).forEach { item ->
            val cardView = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(12, 12, 12, 12)
                setBackgroundColor(Color.rgb(8, 20, 38))
            }
            cardView.addView(label(item.title.ifBlank { "گزارش فید" }, 15f, white, true))
            cardView.addView(label("🛰 ${item.satellite}", 13f, accent, true))
            cardView.addView(label("فرکانس: ${item.frequency}  |  قطبش: ${item.pol}  |  SR: ${item.sr}", 13f, white))
            cardView.addView(label("استاندارد: ${item.transmitted}", 12f, muted))
            val sportsNames = listOf("ESPN", "beIN Sports", "Sky Sports", "Sport TV", "SporTV", "TNT Sports", "DAZN", "Eurosport", "Fox Sports", "Sony Ten")
                .filter { item.searchable.contains(it.lowercase()) }
            if (sportsNames.isNotEmpty()) {
                val badges = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 6, 0, 6) }
                sportsNames.distinct().forEach { name ->
                    val chip = TextView(this).apply {
                        text = "  $name  "
                        textSize = 11f
                        setTextColor(accent)
                        setBackgroundColor(Color.rgb(23, 48, 72))
                        setPadding(8, 5, 8, 5)
                    }
                    badges.addView(chip, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { rightMargin = 6 })
                }
                cardView.addView(badges)
            }
            cardView.addView(label("${item.date}  •  ${item.time}  •  گزارشگر: ${item.reporter}", 11f, muted))
            cardView.setOnClickListener { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(FEED_URL))) }
            feedList.addView(cardView)
            feedList.addView(space(8))
        }
    }

    private fun panel(): LinearLayout {
        val density = resources.displayMetrics.density
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((16*density).toInt(), (16*density).toInt(), (16*density).toInt(), (16*density).toInt())
            setBackgroundColor(card)
        }
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(0, 0, 0, 0)
        }

    private fun space(px: Int): View = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, (px * resources.displayMetrics.density).toInt())
    }

    private fun actionButton(text: String, color: Int, textColor: Int): Button {
        val density = resources.displayMetrics.density
        return Button(this).apply {
            this.text = text
            setBackgroundColor(color)
            setTextColor(textColor)
            textSize = 13f
            minHeight = (48*density).toInt()
            isAllCaps = false
        }
    }

    private fun schedule() {
        val request = PeriodicWorkRequestBuilder<FeedWorker>(15, TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "feed-check", ExistingPeriodicWorkPolicy.UPDATE, request
        )
    }
}
