package com.example.satellifeed

import android.content.Context
import android.util.Base64

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("feeds", Context.MODE_PRIVATE)

    // Comma-separated keywords. Empty = notify about everything.
    var keywords: String
        get() = sp.getString("keywords", "") ?: ""
        set(v) = sp.edit().putString("keywords", v).apply()

    var initialized: Boolean
        get() = sp.getBoolean("initialized", false)
        set(v) = sp.edit().putBoolean("initialized", v).apply()

    fun seen(): Set<String> =
        (sp.getString("seen", "") ?: "").split("\n").filter { it.isNotBlank() }.toSet()

    fun saveSeen(newKeys: List<String>) {
        val merged = (newKeys + seen()).distinct().take(600)
        sp.edit().putString("seen", merged.joinToString("\n")).apply()
    }

    fun saveLatest(items: List<FeedItem>) {
        val encoded = items.take(100).joinToString("\n") { item ->
            listOf(item.reporter, item.date, item.time, item.satellite, item.frequency,
                item.pol, item.sr, item.category, item.transmitted, item.info)
                .joinToString("|") { Base64.encodeToString(it.toByteArray(Charsets.UTF_8), Base64.NO_WRAP) }
        }
        sp.edit().putString("latest", encoded).apply()
    }

    fun latest(): List<FeedItem> = (sp.getString("latest", "") ?: "")
        .lines().filter { it.isNotBlank() }.mapNotNull { line ->
            try {
                val f = line.split("|").map { String(Base64.decode(it, Base64.NO_WRAP), Charsets.UTF_8) }
                if (f.size != 10) null else FeedItem(f[0], f[1], f[2], f[3], f[4], f[5], f[6], f[7], f[8], f[9])
            } catch (_: Exception) { null }
        }

    var lastCheck: String
        get() = sp.getString("lastCheck", "-") ?: "-"
        set(v) = sp.edit().putString("lastCheck", v).apply()
}
