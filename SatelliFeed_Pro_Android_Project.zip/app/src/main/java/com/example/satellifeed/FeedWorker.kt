package com.example.satellifeed

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

const val FEED_URL = "https://www.satelliweb.com/live-feeds-en.html"
private const val CHANNEL_ID = "feeds"

class FeedWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    override suspend fun doWork(): Result {
        val prefs = Prefs(applicationContext)
        return try {
            val html = withContext(Dispatchers.IO) {
                Jsoup.connect(FEED_URL)
                    .userAgent("Mozilla/5.0 (Android) SatelliFeedApp/1.0")
                    .timeout(20_000)
                    .get()
                    .html()
            }
            val items = FeedParser.parse(html)
            prefs.saveLatest(items)
            prefs.lastCheck = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date()) +
                " (${items.size} items)"
            if (items.isEmpty()) return Result.success() // page structure may have changed

            val seen = prefs.seen()
            val fresh = items.filter { it.key !in seen }
            val firstRun = !prefs.initialized
            prefs.saveSeen(items.map { it.key })
            prefs.initialized = true

            // First run only records the current state, so you don't get a flood.
            if (!firstRun && fresh.isNotEmpty()) {
                val words = prefs.keywords.lowercase().split(",").map { it.trim() }.filter { it.isNotEmpty() }
                val matched = if (words.isEmpty()) fresh
                else fresh.filter { item -> words.any { it in item.searchable } }
                notify(matched)
            }
            Result.success()
        } catch (e: IOException) {
            Result.retry()
        }
    }

    private fun notify(items: List<FeedItem>) {
        if (items.isEmpty()) return
        val ctx = applicationContext
        val nm = NotificationManagerCompat.from(ctx)
        if (!nm.areNotificationsEnabled()) return

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL_ID, "New feeds", NotificationManager.IMPORTANCE_DEFAULT)
            ctx.getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
        val open = PendingIntent.getActivity(
            ctx, 0, Intent(Intent.ACTION_VIEW, Uri.parse(FEED_URL)),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        fun build(title: String, text: String) = NotificationCompat.Builder(ctx, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(open)
            .setAutoCancel(true)

        try {
            if (items.size <= 4) {
                items.forEach { nm.notify(it.key.hashCode(), build(it.title, it.body).build()) }
            } else {
                val text = items.take(8).joinToString("\n") { "• ${it.title}" }
                nm.notify(1, build("${items.size} new feeds", text).build())
            }
        } catch (_: SecurityException) { /* notification permission missing */ }
    }
}
