package com.example.satellifeed

import org.jsoup.Jsoup

data class FeedItem(
    val reporter: String,
    val date: String,
    val time: String,
    val satellite: String,
    val frequency: String,
    val pol: String,
    val sr: String,
    val category: String,
    val transmitted: String,
    val info: String
) {
    // The page has no ID per entry, so we build a stable key.
    val key: String get() = "$reporter|$date|$time|$frequency|$pol|$sr"
    val title: String get() = "$category: $info".trim().trimEnd(':')
    val body: String get() = "$satellite — $frequency $pol SR $sr ($transmitted)"
    val searchable: String get() = "$satellite $category $info $transmitted".lowercase()
}

object FeedParser {
    // Works on the flattened page text, e.g.:
    // "stanley_cassidy on 2026-11-20 09:01 pm 2 comments Eutelsat Hot Bird 13 (13.0°E)
    //  Frequency: 11655 - Pol: H - SR: 7120 - FEC: - Category: Sport - Football
    //  Transmitted in: MPEG-4 crypté ℹ Barnsley - Sheffield Wednesday"
    private val entry = Regex(
        """^(\S+) on (\d{4}-\d{2}-\d{2}) (\d{1,2}:\d{2} [ap]m)\s*(?:\d+ comments?)?\s*(.*?)\s*""" +
            """Frequency:\s*(\d+)\s*-\s*Pol:\s*(\w)\s*-\s*SR:\s*(\d+)\s*-\s*FEC:\s*\S*\s*-?\s*""" +
            """Category:\s*(.*?)\s*Transmitted in:\s*(.*?)\s*(?:ℹ\uFE0F?)\s*(.*)$"""
    )

    fun parse(html: String): List<FeedItem> {
        val text = Jsoup.parse(html).body().text()
        return text.split("Reported by ")
            .drop(1)
            .mapNotNull { chunk ->
                // The last chunk also contains the page footer.
                val clean = chunk.substringBefore(" Previous feeds").substringBefore(" Top ").trim()
                val m = entry.find(clean) ?: return@mapNotNull null
                val g = m.groupValues
                FeedItem(
                    reporter = g[1], date = g[2], time = g[3], satellite = g[4],
                    frequency = g[5], pol = g[6], sr = g[7],
                    category = g[8], transmitted = g[9], info = g[10]
                )
            }
    }
}
