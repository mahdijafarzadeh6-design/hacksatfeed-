Satelli Feeds - build instructions
1. Android Studio (Koala or newer) > File > Open > select this folder (SatelliFeed).
2. Let Gradle sync (Studio will offer to create the Gradle wrapper if it's missing).
3. Run on a phone/emulator, or Build > Build APK(s).
4. In the app: enter keywords (optional) > "Save & start monitoring" > allow notifications.
The first check only records what's on the page; notifications start with NEW entries after that.
