# SatelliFeed Pro Android

A dark-themed Android client for SatelliWeb Live Feeds.

## New in this edition
- Feed search across satellite, frequency, polarization, SR, category, transmission and event text
- One-tap categories: All, Football and Basketball
- Sports broadcaster name badges when a supported broadcaster name appears in the feed text
- Feed cards show satellite, frequency, polarization, SR, transmission format and report time
- Existing 15-minute background monitoring, manual refresh and new-feed notifications retained

Broadcaster badges are text labels detected from feed content, not official image logos. A broadcaster badge appears only when its name is present in the feed.

## Build APK
Upload the contents of this `SatelliFeed` directory to the root of a GitHub repository. Open **Actions** and run **Build APK** (or push a commit). Download the `SatelliFeed-apk` artifact from the completed workflow.

## Notes
- Requires Android 7.0 (API 24) or newer.
- Feed availability and parsed fields depend on the current public SatelliWeb page structure and network access.
- Background checks are scheduled by Android WorkManager; the operating system may defer execution to preserve battery.
